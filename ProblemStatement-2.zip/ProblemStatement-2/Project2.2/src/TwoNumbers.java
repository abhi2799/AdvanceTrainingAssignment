//import java.io.*;
//import java.util.*;
public class TwoNumbers {
	class fibseq {
		  public static void main(String[] args) {

		    int i = 1, n = 13, firstTerm=0,secondTerm=1;
		    System.out.println("Fibonacci Series till " + n + " terms:");
		    //Scanner sc = new Scanner(System.in);
		    //System.out.print("firstTerm:");
		    //int firstTerm = new sc.nextInt();
		    //System.out.
		    for(i=1;i<=n;i++) {
		      System.out.print(firstTerm + ", ");

		      int nextTerm = firstTerm + secondTerm;
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;		   
		    }
		  }
		}





}
